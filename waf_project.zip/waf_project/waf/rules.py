"""Detection rules: SQL Injection, XSS, Path Traversal.

Har rule = (rule_id, attack_type, compiled regex, description).
Input pehle normalize hota hai (URL-decode, HTML-unescape) taaki
encoding tricks (%2e%2e%2f, &#x3c; etc.) se bypass na ho.
"""
import html
import re
from urllib.parse import unquote_plus

SQLI, XSS, PATH = "SQL_INJECTION", "XSS", "PATH_TRAVERSAL"

_F = re.IGNORECASE | re.DOTALL

RULES = [
    # ---------- SQL Injection ----------
    ("SQLI-001", SQLI, re.compile(r"\bunion\b(\s|/\*.*?\*/)+(all\s+)?select\b", _F), "UNION SELECT based injection"),
    ("SQLI-002", SQLI, re.compile(r"['\"]\s*(or|and)\s+['\"]?\w+['\"]?\s*(=|like)\s*['\"]?\w+", _F), "Quote-based tautology (' OR '1'='1)"),
    ("SQLI-003", SQLI, re.compile(r"\b(or|and)\s+\d+\s*=\s*\d+", _F), "Numeric tautology (OR 1=1)"),
    ("SQLI-004", SQLI, re.compile(r"['\"]\s*(--|#|/\*)", _F), "Quote followed by SQL comment"),
    ("SQLI-005", SQLI, re.compile(r";\s*(drop|delete|insert|update|alter|create|truncate|exec)\b", _F), "Stacked query"),
    ("SQLI-006", SQLI, re.compile(r"\b(sleep|benchmark|pg_sleep)\s*\(|\bwaitfor\s+delay\b", _F), "Time-based blind injection"),
    ("SQLI-007", SQLI, re.compile(r"\binformation_schema\b|\bsqlite_master\b|\bsys\.(tables|objects)\b", _F), "Schema enumeration"),
    ("SQLI-008", SQLI, re.compile(r"\bload_file\s*\(|\binto\s+(out|dump)file\b|\bxp_cmdshell\b", _F), "File/command SQL functions"),
    # ---------- XSS ----------
    ("XSS-001", XSS, re.compile(r"<\s*/?\s*script\b", _F), "<script> tag"),
    ("XSS-002", XSS, re.compile(r"\bon\w{3,20}\s*=", _F), "Inline event handler (onerror=, onload=)"),
    ("XSS-003", XSS, re.compile(r"(javascript|vbscript)\s*:", _F), "javascript: URI"),
    ("XSS-004", XSS, re.compile(r"<\s*(iframe|object|embed|svg|img|body|link|meta|style)\b[^>]*", _F), "Dangerous HTML tag"),
    ("XSS-005", XSS, re.compile(r"document\s*\.\s*(cookie|location|write)|\beval\s*\(|\balert\s*\(|window\s*\.\s*location", _F), "Dangerous JS API"),
    ("XSS-006", XSS, re.compile(r"data\s*:\s*text/html", _F), "data:text/html URI"),
    # ---------- Path Traversal ----------
    ("PATH-001", PATH, re.compile(r"\.\.[/\\]"), "Directory traversal (../ ..\\)"),
    ("PATH-002", PATH, re.compile(r"/etc/(passwd|shadow|hosts)|/proc/self|/var/log/", _F), "Sensitive Linux path"),
    ("PATH-003", PATH, re.compile(r"boot\.ini|windows[/\\]system32|win\.ini", _F), "Sensitive Windows path"),
    ("PATH-004", PATH, re.compile(r"\x00"), "Null byte injection"),
]


def normalize(value: str, rounds: int = 3) -> str:
    """Multi-pass decode taaki double-encoding bypass na ho."""
    prev = value
    for _ in range(rounds):
        cur = html.unescape(unquote_plus(prev))
        if cur == prev:
            break
        prev = cur
    return prev


def inspect_value(value: str):
    """Ek string scan karo. Returns list of dict (matched rules)."""
    if not value:
        return []
    text = normalize(value)
    hits = []
    for rule_id, attack, pattern, desc in RULES:
        m = pattern.search(text)
        if m:
            hits.append({
                "rule_id": rule_id,
                "attack_type": attack,
                "description": desc,
                "matched": m.group(0)[:80],
            })
    return hits

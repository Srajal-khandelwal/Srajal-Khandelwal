"""JSON-lines logger: har request ek line (allowed + blocked dono)."""
import json
import logging
import os
from logging.handlers import RotatingFileHandler


def get_logger(path: str = "logs/waf.log") -> logging.Logger:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    logger = logging.getLogger(f"waf.{os.path.abspath(path)}")
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        handler = RotatingFileHandler(path, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(handler)
        logger.propagate = False
    return logger


def log_event(logger: logging.Logger, event: dict) -> None:
    logger.info(json.dumps(event, ensure_ascii=False))

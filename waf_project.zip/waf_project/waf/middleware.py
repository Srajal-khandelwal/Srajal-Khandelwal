"""WSGI WAF middleware (Flask/Django/any WSGI app ke saath chalta hai).

Modes:
  block  -> attack mile to 403 return (IPS)
  detect -> sirf log karo, request pass hone do (IDS)
"""
import json
from datetime import datetime, timezone
from io import BytesIO
from urllib.parse import parse_qsl

from .logger import get_logger, log_event
from .rules import inspect_value

SCANNED_HEADERS = ("HTTP_USER_AGENT", "HTTP_REFERER", "HTTP_COOKIE")


def _flatten(obj):
    """JSON ki saari string values nikalo."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield str(k)
            yield from _flatten(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _flatten(v)
    elif obj is not None:
        yield str(obj)


class WAFMiddleware:
    def __init__(self, app, mode="block", log_path="logs/waf.log", max_body=1_000_000):
        if mode not in ("block", "detect"):
            raise ValueError("mode must be 'block' or 'detect'")
        self.app = app
        self.mode = mode
        self.max_body = max_body
        self.logger = get_logger(log_path)

    # -- helpers ---------------------------------------------------------
    def _read_body(self, environ):
        try:
            length = int(environ.get("CONTENT_LENGTH") or 0)
        except ValueError:
            length = 0
        body = environ["wsgi.input"].read(min(length, self.max_body)) if length else b""
        environ["wsgi.input"] = BytesIO(body)  # app ke liye wapas rakh do
        return body

    def _collect(self, environ, body):
        """(location, value) pairs jinko scan karna hai."""
        items = [("path", environ.get("PATH_INFO", ""))]
        items += [("query", f"{k}={v}") for k, v in parse_qsl(environ.get("QUERY_STRING", ""), keep_blank_values=True)]
        items.append(("query_raw", environ.get("QUERY_STRING", "")))
        for h in SCANNED_HEADERS:
            if environ.get(h):
                items.append((f"header:{h[5:].lower()}", environ[h]))
        if body:
            text = body.decode("utf-8", errors="replace")
            ctype = (environ.get("CONTENT_TYPE") or "").lower()
            if "json" in ctype:
                try:
                    items += [("body", v) for v in _flatten(json.loads(text))]
                except ValueError:
                    items.append(("body", text))
            elif "x-www-form-urlencoded" in ctype:
                items += [("body", f"{k}={v}") for k, v in parse_qsl(text, keep_blank_values=True)]
            else:
                items.append(("body", text))
        return items

    def _scan(self, items):
        findings, seen = [], set()
        for location, value in items:
            for hit in inspect_value(value):
                key = (hit["rule_id"], location)
                if key in seen:
                    continue
                seen.add(key)
                hit["location"] = location
                findings.append(hit)
        return findings

    # -- WSGI ------------------------------------------------------------
    def __call__(self, environ, start_response):
        body = self._read_body(environ)
        findings = self._scan(self._collect(environ, body))
        blocked = bool(findings) and self.mode == "block"
        action = "BLOCKED" if blocked else ("DETECTED" if findings else "ALLOWED")
        attack_types = sorted({f["attack_type"] for f in findings})

        log_event(self.logger, {
            "time": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "client_ip": environ.get("HTTP_X_FORWARDED_FOR", environ.get("REMOTE_ADDR", "-")).split(",")[0].strip(),
            "method": environ.get("REQUEST_METHOD"),
            "path": environ.get("PATH_INFO"),
            "query": environ.get("QUERY_STRING", "")[:200],
            "action": action,
            "attack_types": attack_types,
            "findings": findings,
        })

        if blocked:
            payload = json.dumps({"error": "Request blocked by WAF", "attack_types": attack_types}).encode()
            start_response("403 Forbidden", [
                ("Content-Type", "application/json"),
                ("Content-Length", str(len(payload))),
            ])
            return [payload]
        return self.app(environ, start_response)

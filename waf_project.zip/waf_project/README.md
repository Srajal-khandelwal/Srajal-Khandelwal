# Web Application Firewall (WAF) Middleware with Intrusion Detection

SQL Injection, XSS aur Path Traversal detect + block karne wala WSGI middleware.
Python + Flask. Logging aur automated tests included.

## Features
- **Detection**: 18 regex rules (SQLi 8, XSS 6, Path Traversal 4)
- **Normalization**: multi-pass URL-decode + HTML-unescape (double-encoding bypass roka jata hai)
- **Inspection points**: URL path, query string, JSON/form body, headers (User-Agent, Referer, Cookie)
- **Two modes**: `block` (IPS, 403 return) aur `detect` (IDS, sirf log)
- **Logging**: har request JSON-lines format mein `logs/waf.log` (time, IP, method, path, action, rule_id, matched payload)
- **Tests**: 41 pytest tests (rules, false-positives, middleware, logging)

## Structure
```
waf_project/
├── waf/
│   ├── rules.py        # detection rules + normalization
│   ├── middleware.py   # WSGI middleware (block/detect)
│   └── logger.py       # JSON logger
├── app.py              # demo Flask app (WAF ke peeche)
├── simulate_attacks.py # attack demo script
├── tests/test_waf.py   # pytest suite
└── logs/waf.log        # generated logs
```

## Run
```bash
pip install -r requirements.txt
python app.py                    # block mode
WAF_MODE=detect python app.py    # detect-only (IDS) mode
python simulate_attacks.py       # naye terminal mein
python -m pytest -v              # tests
```

## Use in any Flask app
```python
from waf import WAFMiddleware
app.wsgi_app = WAFMiddleware(app.wsgi_app, mode="block")
```

## Sample log entry
```json
{"time": "2026-11-19T10:15:02+00:00", "client_ip": "127.0.0.1", "method": "GET",
 "path": "/search", "action": "BLOCKED", "attack_types": ["SQL_INJECTION"],
 "findings": [{"rule_id": "SQLI-002", "location": "query", "matched": "' OR '1'='1"}]}
```

## Limitations (viva ke liye)
- Regex/signature-based hai, isliye naye ya heavily obfuscated payloads miss ho sakte hain.
- Anomaly/ML detection nahi hai. Rate limiting nahi hai.
- Ye defense-in-depth ka ek layer hai. Asli fix **parameterized queries** aur **output escaping** hai.

## Future scope
IP rate-limiting / auto-ban, ML-based anomaly detection, dashboard for logs, CSRF/SSRF/command-injection rules.

"""Apne hi demo app par test payloads bhejta hai (WAF ka demo/viva ke liye).

Pehle terminal 1 mein:  python app.py
Phir terminal 2 mein:   python simulate_attacks.py
"""
import json
import urllib.error
import urllib.parse
import urllib.request

BASE = "http://127.0.0.1:5000"

TESTS = [
    ("Normal search",        "GET",  "/search", {"q": "laptop"}),
    ("SQLi tautology",       "GET",  "/search", {"q": "' OR '1'='1"}),
    ("SQLi UNION SELECT",    "GET",  "/search", {"q": "1 UNION SELECT username,password FROM users"}),
    ("SQLi stacked query",   "GET",  "/search", {"q": "1; DROP TABLE users"}),
    ("XSS script tag",       "GET",  "/search", {"q": "<script>alert(1)</script>"}),
    ("XSS img onerror",      "GET",  "/search", {"q": "<img src=x onerror=alert(1)>"}),
    ("Path traversal",       "GET",  "/file",   {"name": "../../etc/passwd"}),
    ("Encoded traversal",    "GET",  "/file",   {"name": "%2e%2e%2f%2e%2e%2fetc/passwd"}),
    ("Clean login (JSON)",   "POST", "/login",  {"username": "srajal", "password": "abc123"}),
    ("SQLi in login (JSON)", "POST", "/login",  {"username": "admin' --", "password": "x"}),
]


def send(method, path, params):
    if method == "GET":
        req = urllib.request.Request(f"{BASE}{path}?{urllib.parse.urlencode(params)}")
    else:
        req = urllib.request.Request(f"{BASE}{path}", data=json.dumps(params).encode(),
                                     headers={"Content-Type": "application/json"}, method="POST")
    try:
        return urllib.request.urlopen(req).status
    except urllib.error.HTTPError as e:
        return e.code


if __name__ == "__main__":
    print(f"{'Test':<24}{'Status':<8}Result")
    print("-" * 44)
    for name, method, path, params in TESTS:
        code = send(method, path, params)
        print(f"{name:<24}{code:<8}{'BLOCKED' if code == 403 else 'ALLOWED'}")
    print("\nLogs dekhne ke liye: logs/waf.log")

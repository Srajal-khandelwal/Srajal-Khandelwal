import json
import os
import sys

import pytest
from flask import Flask, jsonify, request

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from waf import WAFMiddleware, inspect_value  # noqa: E402


def make_client(mode, tmp_path):
    app = Flask(__name__)

    @app.route("/search")
    def search():
        return jsonify(q=request.args.get("q", ""))

    @app.route("/login", methods=["POST"])
    def login():
        return jsonify(ok=True)

    log_path = str(tmp_path / f"{mode}.log")
    app.wsgi_app = WAFMiddleware(app.wsgi_app, mode=mode, log_path=log_path)
    return app.test_client(), log_path


@pytest.fixture
def client(tmp_path):
    return make_client("block", tmp_path)


# ---------- Unit tests: rules ----------
@pytest.mark.parametrize("payload", [
    "' OR '1'='1", "1 OR 1=1", "1 UNION SELECT username,password FROM users",
    "admin' --", "1; DROP TABLE users", "1 AND SLEEP(5)", "x UNION/**/SELECT 1",
    "SELECT * FROM information_schema.tables",
])
def test_sqli_detected(payload):
    assert any(h["attack_type"] == "SQL_INJECTION" for h in inspect_value(payload))


@pytest.mark.parametrize("payload", [
    "<script>alert(1)</script>", "<img src=x onerror=alert(1)>",
    "javascript:alert(1)", "<svg onload=alert(1)>", "%3Cscript%3Ealert(1)%3C/script%3E",
    "&lt;script&gt;alert(1)&lt;/script&gt;",
])
def test_xss_detected(payload):
    assert any(h["attack_type"] == "XSS" for h in inspect_value(payload))


@pytest.mark.parametrize("payload", [
    "../../etc/passwd", "..\\..\\windows\\system32", "%2e%2e%2f%2e%2e%2fetc/passwd",
    "%252e%252e%252fsecret", "file.txt%00.jpg", "/etc/shadow",
])
def test_path_traversal_detected(payload):
    assert any(h["attack_type"] == "PATH_TRAVERSAL" for h in inspect_value(payload))


@pytest.mark.parametrize("payload", [
    "hello world", "O'Brien", "I love rock and roll", "price: 100-200",
    "John Smith", "report.pdf", "user@example.com", "select your favourite colour",
    "union of india", "version 1.2.3",
])
def test_benign_not_flagged(payload):
    assert inspect_value(payload) == []


# ---------- Integration tests: middleware ----------
def test_clean_request_allowed(client):
    c, _ = client
    r = c.get("/search?q=laptop")
    assert r.status_code == 200 and r.json["q"] == "laptop"


def test_sqli_blocked_in_query(client):
    c, _ = client
    r = c.get("/search", query_string={"q": "' OR '1'='1"})
    assert r.status_code == 403 and "SQL_INJECTION" in r.json["attack_types"]


def test_xss_blocked_in_query(client):
    c, _ = client
    r = c.get("/search", query_string={"q": "<script>alert(1)</script>"})
    assert r.status_code == 403 and "XSS" in r.json["attack_types"]


def test_path_traversal_blocked_in_url(client):
    c, _ = client
    r = c.get("/search?q=../../etc/passwd")
    assert r.status_code == 403 and "PATH_TRAVERSAL" in r.json["attack_types"]


def test_encoded_traversal_in_path_blocked(client):
    c, _ = client
    assert c.get("/files/%2e%2e%2f%2e%2e%2fetc/passwd").status_code == 403


def test_json_body_blocked(client):
    c, _ = client
    r = c.post("/login", json={"username": "admin' --", "password": "x"})
    assert r.status_code == 403


def test_form_body_blocked(client):
    c, _ = client
    r = c.post("/login", data={"username": "<script>alert(1)</script>", "password": "x"})
    assert r.status_code == 403


def test_clean_json_body_allowed(client):
    c, _ = client
    assert c.post("/login", json={"username": "srajal", "password": "pass123"}).status_code == 200


def test_header_attack_blocked(client):
    c, _ = client
    r = c.get("/search?q=hi", headers={"User-Agent": "<script>alert(1)</script>"})
    assert r.status_code == 403


def test_detect_mode_logs_but_allows(tmp_path):
    c, log_path = make_client("detect", tmp_path)
    r = c.get("/search", query_string={"q": "' OR 1=1 --"})
    assert r.status_code == 200
    last = json.loads(open(log_path).read().strip().splitlines()[-1])
    assert last["action"] == "DETECTED"


def test_logging_blocked_and_allowed(tmp_path):
    c, log_path = make_client("block", tmp_path)
    c.get("/search?q=ok")
    c.get("/search", query_string={"q": "1 UNION SELECT 1,2"})
    lines = [json.loads(l) for l in open(log_path).read().strip().splitlines()]
    assert [l["action"] for l in lines] == ["ALLOWED", "BLOCKED"]
    assert lines[1]["attack_types"] == ["SQL_INJECTION"]
    assert lines[1]["findings"][0]["rule_id"].startswith("SQLI")

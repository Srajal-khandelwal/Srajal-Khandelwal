"""Demo Flask app jo WAF middleware ke peeche chal raha hai.

Run:  python app.py            (block mode)
      WAF_MODE=detect python app.py   (sirf logging, IDS mode)
"""
import os
from flask import Flask, jsonify, request
from markupsafe import escape
from waf import WAFMiddleware

app = Flask(__name__)


@app.route("/")
def home():
    return jsonify(message="Demo app running behind WAF", routes=["/search?q=", "/file?name=", "POST /login"])


@app.route("/search")
def search():
    return f"<h1>Results for: {escape(request.args.get('q', ''))}</h1>"


@app.route("/file")
def file():
    return jsonify(requested_file=request.args.get("name", ""))


@app.route("/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or request.form
    return jsonify(status="login attempt received", user=str(escape(data.get("username", ""))))


# WAF middleware yahan lagta hai
app.wsgi_app = WAFMiddleware(app.wsgi_app, mode=os.getenv("WAF_MODE", "block"), log_path="logs/waf.log")

if __name__ == "__main__":
    app.run(port=5000)
